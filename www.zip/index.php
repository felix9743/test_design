<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="initial-scale=1">
		<link rel="icon" type="image/png" href="/resc/img/favicon.png">

		<link rel="stylesheet" type="text/css" href="/resc/css/default.css">
		<link rel="stylesheet" type="text/css" href="/resc/css/menu.css">
		<link rel="stylesheet" type="text/css" href="/resc/css/colors/light.css">
	</head>
	<body>
		<div class="menu">
			<!-- Menu des Téléphone -->
			<nav class="mb_menu">
				<input class="mb_menu_cbox" type="checkbox">
				<img   class="mb_menu_img1" src="/resc/img/menu_img/menu1.png">
				<img   class="mb_menu_img2" src="/resc/img/menu_img/menu2.png">

				<div class="mb_menu_link">
					<section class="mb_ml_content">
						<ul>
							<li><a href="#">Dessin</a></li>
							<li><a href="#">Comics</a></li>
							<li><a href="#">PortFolio</a></li>
							<li><a href="#">A propos</a></li>
						</ul>
					</section>

					<section class="mb_ml_social">
						<a href="#facebook"><img src="/resc/img/social_img/facebook.svg"></a>
						<a href="#twitter"><img src="/resc/img/social_img/twitter.svg"></a>
						<a href="#instagram"><img src="/resc/img/social_img/instagram.svg"></a>
						<a href="#tumblr"><img src="/resc/img/social_img/tumblr.svg"></a>
					</section>
				</div>
			</nav>

			<!-- Menu des Tablette & Ordinateur -->
			<nav class="tabcom_menu"></nav>
		</div>
	</body>
</html>